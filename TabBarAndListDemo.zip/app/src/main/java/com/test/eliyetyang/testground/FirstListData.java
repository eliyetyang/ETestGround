package com.test.eliyetyang.testground;

/**
 * Created by eliyetyang on 15-5-28.
 */
public class FirstListData {
    private String name;

    public FirstListData(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
