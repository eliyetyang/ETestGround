package com.test.eliyetyang.testground;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RadioGroup;

import java.util.ArrayList;


public class MainActivity extends ActionBarActivity {
    private ArrayList<Fragment> mFragments;
    private RadioGroup mTabGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final FragmentManager fragmentManager = getFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        mFragments = new ArrayList<>();
        mFragments.add(new ListFragmentFirst());
        mFragments.add(new FragmentSecond());
        fragmentTransaction.add(R.id.main_content, new ListFragmentFirst(), "first");
        fragmentTransaction.add(R.id.main_content, mFragments.get(1), "second");
        fragmentTransaction.show(mFragments.get(0));
        fragmentTransaction.hide(mFragments.get(1));
        fragmentTransaction.commit();

        mTabGroup = (RadioGroup) findViewById(R.id.tab_group);
        mTabGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                int curTagIndex = 0;
                switch (checkedId) {
                    case R.id.tab_first:
                        curTagIndex = 0;
                        break;
                    case R.id.tab_second:
                        curTagIndex = 1;
                        break;
                    default:
                        break;
                }
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.show(mFragments.get(curTagIndex));
                for (int i = 0; i < mFragments.size(); i++) {
                    if (i != curTagIndex) {
                        fragmentTransaction.hide(mFragments.get(i));
                    }
                }
                fragmentTransaction.commit();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
